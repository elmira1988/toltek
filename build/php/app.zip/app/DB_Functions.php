<?php
class DB_Functions {
    private $conn;

    function __construct() {
        require_once 'connection.php';
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    public function storeUser($l_name, $f_name, $mail, $mw_s, $pass) {
        $uid = uniqid('', true);
        $hash = $this->hashSSHA($pass);
        $pass = $hash["encrypted"];
        $salt = $hash["salt"];
 
        $stmt = $this->conn->prepare("INSERT INTO app_users(uid, l_name, f_name, mail, mw_s, pass, salt) VALUES(?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $uid, $l_name, $f_name, $mail, $mw_s, $pass, $salt);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM app_users WHERE mail = ?");
            $stmt->bind_param("s", $mail);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            return $user;
        } else {
            return false;
        }
    }
 
    public function getUserByEmailAndPassword($mail, $pass) {
 
        $stmt = $this->conn->prepare("SELECT * FROM app_users WHERE mail = ?");
        $stmt->bind_param("s", $mail);
        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
 
            // verifying user password
            $salt = $user['salt'];
            $enc_pass = $user['pass'];
            $hash = $this->checkhashSSHA($salt, $pass);
            if ($enc_pass == $hash) {
                return $user;
            }
        } else {
            return NULL;
        }
    }
 
    public function isUserExisted($mail) {
        $stmt = $this->conn->prepare("SELECT mail FROM app_users WHERE mail = ?");
        $stmt->bind_param("s", $mail);
        $stmt->execute();
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }
 
    public function hashSSHA($pass) {
        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($pass . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }
 
    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($salt, $pass) {
        $hash = base64_encode(sha1($pass . $salt, true) . $salt);
        return $hash;
    }
}
?>