<?php
define("DB_HOST", "localhost");
define("DB_USER", "046013955_arimle");
define("DB_PASSWORD", "arimLe");
define("DB_DATABASE", "toltekplus_adminnew");
?>